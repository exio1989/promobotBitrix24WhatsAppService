-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Май 05 2019 г., 10:05
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `hiravv2p_crmprom`
--

-- --------------------------------------------------------

--
-- Структура таблицы `whatsapp_sended_messages`
--
-- Создание: Май 04 2019 г., 18:00
-- Последнее обновление: Май 05 2019 г., 06:52
--

DROP TABLE IF EXISTS `whatsapp_sended_messages`;
CREATE TABLE `whatsapp_sended_messages` (
  `id` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `sent_date` datetime DEFAULT NULL,
  `viewed_date` datetime DEFAULT NULL,
  `event_type` varchar(50) NOT NULL,
  `message` varchar(200) NOT NULL,
  `create_date` datetime NOT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `deal_id` int(11) DEFAULT NULL,
  `chat_api_message_id` varchar(50) NOT NULL,
  `delivered_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `whatsapp_sended_messages`
--

INSERT INTO `whatsapp_sended_messages` (`id`, `phone`, `sent_date`, `viewed_date`, `event_type`, `message`, `create_date`, `lead_id`, `deal_id`, `chat_api_message_id`, `delivered_date`) VALUES
(19, '79222404771', '2019-05-05 06:24:29', '2019-05-05 06:24:45', 'event1', 'Привет, Вася! Лид изменен.', '2019-05-05 06:24:29', NULL, 0, 'true_79222404771@c.us_3EB0C7D21F8A5839B3C7', '2019-05-05 06:24:32'),
(21, '89222404311', NULL, NULL, 'OnLeadUpdate', 'Привет, Вася! Лид изменен.', '2019-05-05 06:50:43', 5, 0, 'true_89222404311@c.us_3EB0367E41A5D637B145', NULL),
(22, '79222404771', '2019-05-05 06:52:08', '2019-05-05 06:52:29', 'OnLeadUpdate', 'Привет, Вася! Лид изменен.', '2019-05-05 06:52:07', 7, 0, 'true_79222404771@c.us_3EB0BD2AF726F6C540FB', '2019-05-05 06:52:14');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `whatsapp_sended_messages`
--
ALTER TABLE `whatsapp_sended_messages`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `whatsapp_sended_messages`
--
ALTER TABLE `whatsapp_sended_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
